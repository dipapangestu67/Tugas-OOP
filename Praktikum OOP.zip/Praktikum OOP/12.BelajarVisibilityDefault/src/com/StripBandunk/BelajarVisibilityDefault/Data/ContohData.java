/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.StripBandunk.Visibility.Data;

/**
 *
 * @author hp
 */
public class ContohData {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Dosen a = new Dosen();
        a.nip = "12471824";
        a.nama = "Eko";
        a.alamat = "Subang";
        
        a.tampilInformasi();
    }
    
}
