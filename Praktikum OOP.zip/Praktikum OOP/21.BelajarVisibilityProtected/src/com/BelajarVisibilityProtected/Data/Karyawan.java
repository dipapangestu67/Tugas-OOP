/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.BelajarVisibilityProtected.Data;

/**
 *
 * @author iipsu
 */
public class Karyawan extends Orang{
    public void tampilInformasi(){
    System.out.println(super.nama);
    System.out.println(super.alamat);
    }
}
