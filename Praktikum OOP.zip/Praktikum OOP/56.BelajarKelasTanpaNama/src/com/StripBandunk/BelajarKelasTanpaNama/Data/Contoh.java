/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.StripBandunk.BelajarKelasTanpaNama.Data;

/**
 *
 * @author iipsu
 */
public abstract class Contoh {
    public abstract void prosedur();
    public abstract String fungsi();
}
