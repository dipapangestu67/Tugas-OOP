/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.StripBandunk.BelajarPolimorfismeParameter.Data;

/**
 *
 * @author iipsu
 */
public class Senjata {
    public void tembak(){
    System.out.println("Dor Dor Dor");
    }
    
}
