/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class Matematika {
    int tambah(int nilai1, int nilai2){
    int hasil = nilai1 + nilai2;
    return hasil;
    }
    
    int kurang(int nilai1, int nilai2){
    int hasil = nilai1 - nilai2;
    return hasil;
    }
    
    int kali(int nilai1, int nilai2){
    int hasil = nilai1 * nilai2;
    return hasil;
    }
    
    double bagi(double nilai1, double nilai2){
    double hasil = nilai1 / nilai2;
    return hasil;
    }
}
