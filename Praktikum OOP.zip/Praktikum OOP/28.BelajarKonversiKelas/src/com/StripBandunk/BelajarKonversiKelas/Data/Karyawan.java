/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.StripBandunk.BelajarKonversiKelas.Data;

/**
 *
 * @author iipsu
 */
public class Karyawan extends Manusia {
    public void karyawan(){
    System.out.println("Karyawan");
    }
}
