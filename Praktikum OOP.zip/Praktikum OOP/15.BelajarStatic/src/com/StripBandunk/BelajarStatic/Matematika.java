/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.StripBandunk.BelajarStatic;

/**
 *
 * @author iipsu
 */
public class Matematika {
   public static int tambah(int nilai1, int nilai2){
   int hasil = nilai1 + nilai2;
   return hasil;
   }
   public static int kurang(int nilai1, int nilai2){
   int hasil = nilai1 - nilai2;
   return hasil;
   } 
}
