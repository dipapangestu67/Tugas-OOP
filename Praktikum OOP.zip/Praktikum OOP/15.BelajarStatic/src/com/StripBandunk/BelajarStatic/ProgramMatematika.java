/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.StripBandunk.BelajarStatic;

/**
 *
 * @author iipsu
 */
public class ProgramMatematika {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int hasil = Matematika.tambah(100, 100);
        System.out.println(hasil);
        
        hasil = Matematika.kurang(100, 100);
        System.out.println(hasil);
    }
    
}
