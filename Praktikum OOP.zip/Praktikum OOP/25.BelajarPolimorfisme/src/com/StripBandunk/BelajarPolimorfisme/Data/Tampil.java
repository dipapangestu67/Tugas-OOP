/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.StripBandunk.BelajarPolimorfisme.Data;

/**
 *
 * @author iipsu
 */
public class Tampil {
    public static void tampil(Manusia manusia){
    System.out.println("Nama : " + manusia.getNama());
    System.out.println("Alamat : " + manusia.getAlamat());
    }
}
